package com.lec.quiz;

public class MemberTestMain {
	public static void main(String[] args) {
		Member customer = new Member("aaa", "xxx","ȫ�浿", "hong@company.com", "���� ������", "2000-01-01", 'M');
		System.out.println(customer.infoPrint());
		
		
	}
}
