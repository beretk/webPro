package com.lec.ex2_date;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

public class QuizSawonMain {
	public static void main(String[] args) {
		 
		QuizSawon hong = new QuizSawon("202301","ȫ�浿","COMPUTER");
		QuizSawon shin = new QuizSawon("202201", "�ű浿", "DESIGN", 2022, 1, 1);
		System.out.println(hong.infString());
		System.out.println(shin.infString());
		
		
	}
}
